def good_func(n):
    return n